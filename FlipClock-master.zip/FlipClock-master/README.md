# FlipClock.js

### Installation

FlipClock.js can be installed in the following ways:

#### Bower

	bower install FlipClock

#### Node (NPM)

	npm install flipclock

#### Download .zip

[Download .ZIP](https://github.com/objectivehtml/FlipClock/releases)

---

### Demo & Documentation

Website and documentation at http://flipclockjs.com/

---

### License

Copyright (c) 2013 Objective HTML, LCC shared under MIT LICENSE
